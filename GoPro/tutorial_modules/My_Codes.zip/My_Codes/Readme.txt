Steps:
1) Turn on the go pros: leave it on application GoPro quik mode

2) Run locate system code

3) Scan the following barcode to make 240FPS available: 
mVr10p30fNcNe0L2w40i8M8sMe0fL0
https://gopro.github.io/labs/control/custom/

**The command fL0 is for a linear image adjustment for the camera. This is not mentioned in the provided link. It can be found in the following link.

4) Use GoProSettingChanger to change to preferred FPS 
	
5)Start/Stop capture using GoProStarter
For several trials
	

6) Collect the data using GoProCollector


2BImp:
GoProSettingChanger: Add resolution
GoProCollector: Several Wifi Connection Trial